from bin import Bin
from avl import AVLTree
from object import Object, Color
from exceptions import NoBinFoundException
from node import Node

class GCMS:
    def __init__(self):
        # Maintain all the Bins and Objects in GCMS
        self.bin_id=AVLTree()
        self.bin_capacity=AVLTree()
        self.object_id=AVLTree()

    def Largest_Max(self,obj,node:Node):
        # print("came inside largest max")

        li=[]
        self.bin_capacity.in_order_traversal(self.bin_capacity.root,li)
        # print('inorder traversal before adding object',li,'root is',self.bin_capacity.root.key1)
        cur = node
        while(cur.right!=None):
            cur = cur.right

        if cur.key1<obj.size:
            raise NoBinFoundException
        node=cur
        # point=node.ptr
        # print("point 1",point)
        # print('object_id',obj.object_id,'capacity->',node.key1,'id->',node.key2)
        # print("pn",cur.key1)
        #rebalance the tree

        new_size=node.key1-obj.size  
        # cc_cur_id=node.key2
        # # li=[]
        # cur_node=Node(new_size,cc_cur_id)
        # cur_node.ptr=point
        # eeq=node
        # eeq.key1=new_size
        node9=Node(new_size,node.key2)
        node9.ptr=node.ptr
        self.bin_capacity.root=self.bin_capacity._delete_node(node,self.bin_capacity.root)
        # self.bin_capacity.in_order_traversal(self.bin_capacity.root,li)
        # print('inorder traversal after deleye',li)
        
        # self.bin_capacity.insert_node_2(new_size,cc_cur_id)
        # self.bin_capacity.insert(cur_node,self.bin_capacity.root)
        self.bin_capacity.insert(node9,self.bin_capacity.root)

        # li=[]
        # self.bin_capacity.in_order_traversal(self.bin_capacity.root,li)
        # print('inorder traversal after insert',li,'root is ',self.bin_capacity.root.key1)
        # # #rebalancing process ends
        # print("cur_node.ptr",cur_node.ptr)
        
        node9.ptr.avl.insert_node_2(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
        node9.ptr.capacity -= obj.size
        curb_id=cur.ptr.bin_id
        print('id to be searched is ',curb_id)
        nodee=self.bin_id.search_id(self.bin_id.root,curb_id) #searched the node in b_id 
                                                            #(to check if self.b_id.root passses the root or some other node)
        print(nodee.key2)                                           
        nodee.key2=nodee.key2-obj.size #updated the size 
        print("nodee key1",nodee.key1,"key2",nodee.key2)

        oid_nodee=self.object_id.search_id(self.object_id.root,obj.object_id) #found the node of that particular id of object
        # print("oid_nodee key1",oid_nodee.key1,"key2",oid_nodee.key2)
        # print('-------------------------------')
        # print(oid_nodee.ptr)
        oid_nodee.ptr=nodee.ptr
        # print(oid_nodee.ptr.bin_id)

    def Largest_Least(self,obj,node:Node):
        # print(f"for obj=> id: {obj.object_id} , size: {obj.size}")

        # print(f"for node=> id: {node.id} , size: {node.key}")
        pn=None
        cur=node
        while(cur!=None):
            if(cur.key1<obj.size):
                cur=cur.right

            elif(cur.key1 >=obj.size and pn==None):
                pn=cur
                cur=cur.right
            
            elif(cur.key1>pn.key1):
                pn=cur 
                cur=cur.right 
            
            else:
                cur=cur.right

        cur1=pn

        while(True):
            if(pn.left and pn.left.key1==pn.key1):
                pn=pn.left
                cur1=cur1.left
            elif (pn.left and pn.left.key1!=pn.key1):
                cur1=pn.left
                while(cur!=None):
                    if (cur1.key1==pn.key1):
                        pn=cur1
                        break
                    cur1=cur1.right
            
            if(cur1==None or pn.left==None):
                break
        
        if pn==None:
            raise NoBinFoundException
        
        node=pn
        print("pn",pn.key1)
        #rebalance the tree
        new_size=node.key1-obj.size  
        cc_cur_id=node.key2
        self.bin_capacity.root=self.bin_capacity._delete_node(node,self.bin_capacity.root)
        self.bin_capacity.insert_node_2(new_size,cc_cur_id)
        # #rebalancing process ends


        
        node.ptr.avl.insert_node_2(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
        node.ptr.capacity -= obj.size
        curb_id=node.ptr.bin_id

        nodee=self.bin_id.search_id(self.bin_id.root,curb_id) #searched the node in b_id 
                                                            #(to check if self.b_id.root passses the root or some other node)

        nodee.key2=nodee.key2-obj.size #updated the size 

        oid_nodee=self.object_id.search_id(self.object_id.root,obj.size) #found the node of that particular id of object
        # print(oid_nodee)
        oid_nodee.ptr=nodee.ptr
    # def Largest_Max(self,obj,node):

    #     if obj.size > node.size:
    #         self.Largest_Least(obj,node.right)

    #     elif obj.size<node.size:
    #         if self.b_cap.max_value_node(node.right):
    #             self.Compact_Least(obj,node.right)
    #         else:
    #             # (add the code between two red dots)
    #             #rebalance the tree
    #             new_size=node.size-obj.size  
    #             cc_cur_id=node.id
    #             self.b_cap.delete(node.size,node.id)
    #             self.b_cap.insert(new_size,cc_cur_id)
    #             # #rebalancing process ends


                
    #             node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
    #             node.ptr.capacity -= obj.size
    #             curb_id=node.ptr.bin_id

    #             nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
    #                                                                 #(to check if self.b_id.root passses the root or some other node)

    #             nodee.key2=nodee.key2-obj.size #updated the size 

    #             oid_nodee=self.object_id.search_id(self.object_id.root,obj.object_id) #found the node of that particular id of object

    #             oid_nodee.ptr=nodee.ptr

    #     else:
    #         cur = node 
    #         while(cur.right and cur.right.size==node.size):
    #             cur = cur.right 
    #         node=cur
    #         # (add the code between two red dots)
    #         #rebalance the tree
    #         new_size=node.size-obj.size  
    #         cc_cur_id=node.id
    #         self.b_cap.delete(node.size,node.id)
    #         self.b_cap.insert(new_size,cc_cur_id)
    #         # #rebalancing process ends


            
    #         node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
    #         node.ptr.capacity -= obj.size
    #         curb_id=node.ptr.bin_id

    #         nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
    #                                                             #(to check if self.b_id.root passses the root or some other node)

    #         nodee.key=nodee.key-obj.size #updated the size 

    #         oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

    #         oid_nodee.ptr=nodee.ptr

            

    def add_bin(self, bin_id1, capacity1):
        cur_bin=Bin(bin_id1,capacity1)
        self.bin_id.insert_node_3(bin_id1,capacity1,cur_bin)
        self.bin_capacity.insert_node_3(capacity1,bin_id1,cur_bin)
        pass

    def add_object(self, object_id, size, color):
        ## adding bin id and cap. in the trees 
        cur_obj=Object(object_id, size, color)
        # self.o_id.insert_node_3(object_id,size,cur_obj)
        self.object_id.insert_node_2(object_id,size)
        # print("color wali id and key",self.object_id.root.key2,self.object_id.root.key1)
        # print("obj wali color wali id and key",cur_obj.object_id,cur_obj.size)


        # if (color==Color.BLUE):
        #     self.Compact_Least(cur_obj,self.b_cap.root)
        
        # elif (color==Color.YELLOW):
        #     self.Compact_Max(cur_obj,self.b_cap.root)

        # elif (color==Color.RED):
            # print(1)
        if color==Color.RED: 
            self.Largest_Least(cur_obj,self.bin_capacity.root)
        elif (color==Color.GREEN):
            # print("came inside green")
            self.Largest_Max(cur_obj,self.bin_capacity.root)

    # def delete_object(self, object_id):
    #     # Implement logic to remove an object from its bin

    #     my_obj = self.o_id.search_id(self.o_id.root,object_id) #node obtained which has the id of the particular object
    #     obj_size= my_obj.key
    #     b=my_obj.ptr #came to bin
    #     b_i= b.bin_id

    #     b.avl.delete(object_id,obj_size) #to check if this 0 works as the cap

    #     my_obj.ptr=None
    #     self.o_id.delete(object_id,obj_size) #deleting the object from o_id avl tree

    #     cur_bin_id=self.b_id.search_id(self.b_id.root,b_i) #node in b_id obtained of the bin cap in which deletion was made  
    #     b_c=cur_bin_id.key
    #     cur_bin_id.key+=obj_size
        
    #     cur_bin_cap=self.b_cap.search_key(self.b_cap.root,b_c)
    #     b_cap=cur_bin_cap.key
    #     b_iid=cur_bin_cap.id
    #     self.b_cap.delete(cur_bin_cap.id,cur_bin_cap.key)
    #     self.b_cap.insert_node_2(b_cap,b_iid)

    #     # cur_bin_cap.key+=obj_size

    #     ##REBALANCE THE NODE


    #     pass

    def bin_info(self, bin_id):
        # returns a tuple with current capacity of the bin and the list of objects in the bin (int, list[int])
        # print("search in bin info for bin id ", bin_id)
        cur_bin_id = self.bin_id.search_id(self.bin_id.root,bin_id)
        # print(cur_bin_id)
        cur_bin=cur_bin_id.ptr
        ans=[]
        cur_bin.avl.in_order_traversal(cur_bin.avl.root,ans)
        tup = (cur_bin.capacity,ans)

        return tup

    #     pass

    # def object_info(self, object_id):
    #     # returns the bin_id in which the object is stored
    #     cur_o_id=self.o_id.search_id(self.o_id.root,object_id)
    #     cur_b=cur_o_id.ptr
    #     return cur_b.bin_id
    
    #     pass