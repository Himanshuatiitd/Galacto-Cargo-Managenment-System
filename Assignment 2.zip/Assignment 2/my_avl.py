from node import Node
# # # from bin import Bin

# # # # def comp_1(node_1, node_2):
# # # #     return node_1.key < node_2.key

# # # # # class AVLTree:
# # # # #     def __init__(self, compare_function=comp_1):
# # # # #         self.root = None
# # # # #         self.size = 0
# # # # #         self.comparator = compare_function
        
# # # # #     def height(self, node):
# # # # #         if not node:
# # # # #             return 0
# # # # #         return node.height
    
# # # # #     def right_rotate(self, y):
# # # # #         x = y.left
# # # # #         T2 = x.right

# # # # #         # Perform rotation
# # # # #         x.right = y
# # # # #         y.left = T2
    
# # # # #         # Update heights
# # # # #         y.height = 1 + max(self.height(y.left), self.height(y.right))
# # # # #         x.height = 1 + max(self.height(x.left), self.height(x.right))
    
# # # # #         # Return new root
# # # # #         return x
        
# # # # #     def left_rotate(self, x):
# # # # #         y = x.right
# # # # #         T2 = y.left
    
# # # # #         # Perform rotation
# # # # #         y.left = x
# # # # #         x.right = T2
    
# # # # #         # Update heights
# # # # #         x.height = 1 + max(self.height(x.left), self.height(x.right))
# # # # #         y.height = 1 + max(self.height(y.left), self.height(y.right))
    
# # # # #         # Return new root
# # # # #         return y
        
# # # # #     def get_balance(self, node):
# # # # #         if not node:
# # # # #             return 0
# # # # #         return self.height(node.left) - self.height(node.right)

# # # # #     def insert(self, root, new):
# # # # #         # Perform the normal BST insertion
# # # # #         if root is None:
# # # # #             return new
        
# # # # #         if new.get_key() < root.get_key():
# # # # #             root.left = self.insert(root.left, new)
# # # # #         elif new.get_key() > root.get_key():
# # # # #             root.right = self.insert(root.right, new)
# # # # #         else:
# # # # #             if new.get_id() < root.get_id():
# # # # #                 root.left = self.insert(root.left, new)
# # # # #             else:
# # # # #                 root.right = self.insert(root.right, new)

# # # # #         # Update height of this ancestor node
# # # # #         root.height = 1 + max(self.height(root.left), self.height(root.right))
    
# # # # #         # Get the balance factor of this ancestor node
# # # # #         balance = self.get_balance(root)
    
# # # # #         # If this node becomes unbalanced, 
# # # # #         # then there are 4 cases

# # # # #         # Left Left Case
# # # # #         if balance > 1 and new.get_key() < root.left.get_key():
# # # # #             return self.right_rotate(root)
    
# # # # #         # Right Right Case
# # # # #         if balance < -1 and new.get_key() > root.right.get_key():
# # # # #             return self.left_rotate(root)
    
# # # # #         # Left Right Case
# # # # #         if balance > 1 and new.get_key() > root.left.get_key():
# # # # #             root.left = self.left_rotate(root.left)
# # # # #             return self.right_rotate(root)
    
# # # # #         # Right Left Case
# # # # #         if balance < -1 and new.get_key() < root.right.get_key():
# # # # #             root.right = self.right_rotate(root.right)
# # # # #             return self.left_rotate(root)
    
# # # # #         # Return the (unchanged) node pointer
# # # # #         return root


# # # # class AVLTree:
# # # #     def __init__(self, compare_function=comp_1):
# # # #         self.root = None
# # # #         self.size = 0
# # # #         self.comparator = compare_function
    
# # # #     def height(self, node):
# # # #         if not node:
# # # #             return 0
# # # #         return node.height
    
# # # #     def right_rotate(self, y):
# # # #         x = y.left
# # # #         T2 = x.right

# # # #         # Perform rotation
# # # #         x.right = y
# # # #         y.left = T2

# # # #         # Update heights
# # # #         y.height = 1 + max(self.height(y.left), self.height(y.right))
# # # #         x.height = 1 + max(self.height(x.left), self.height(x.right))

# # # #         # Return new root
# # # #         return x
    
# # # #     def left_rotate(self, x):
# # # #         y = x.right
# # # #         T2 = y.left

# # # #         # Perform rotation
# # # #         y.left = x
# # # #         x.right = T2

# # # #         # Update heights
# # # #         x.height = 1 + max(self.height(x.left), self.height(x.right))
# # # #         y.height = 1 + max(self.height(y.left), self.height(y.right))

# # # #         # Return new root
# # # #         return y
    
# # # #     def get_balance(self, node):
# # # #         if not node:
# # # #             return 0
# # # #         return self.height(node.left) - self.height(node.right)

# # # #     def insert(self, root, new):
# # # #         # Perform the normal BST insertion
# # # #         if root is None:
# # # #             return new
        
# # # #         if self.comparator(new, root):
# # # #             root.left = self.insert(root.left, new)
# # # #         elif self.comparator(root, new):
# # # #             root.right = self.insert(root.right, new)
# # # #         else:
# # # #             if new.get_id() < root.get_id():
# # # #                 root.left = self.insert(root.left, new)
# # # #             else:
# # # #                 root.right = self.insert(root.right, new)

# # # #         # Update height of this ancestor node
# # # #         root.height = 1 + max(self.height(root.left), self.height(root.right))

# # # #         # Get the balance factor of this ancestor node
# # # #         balance = self.get_balance(root)

# # # #         # If the node is unbalanced, then there are 4 cases:

# # # #         # Left Left Case
# # # #         if balance > 1 and self.comparator(new, root.left):
# # # #             return self.right_rotate(root)

# # # #         # Right Right Case
# # # #         if balance < -1 and self.comparator(root.right, new):
# # # #             return self.left_rotate(root)

# # # #         # Left Right Case
# # # #         if balance > 1 and self.comparator(root.left, new):
# # # #             root.left = self.left_rotate(root.left)
# # # #             return self.right_rotate(root)

# # # #         # Right Left Case
# # # #         if balance < -1 and self.comparator(new, root.right):
# # # #             root.right = self.right_rotate(root.right)
# # # #             return self.left_rotate(root)

# # # #         return root
    
# # # #     def min_value_node(self, node):
# # # #         current = node
# # # #         while current.left is not None:
# # # #             current = current.left
# # # #         return current

# # # #     def delete(self, root, key, id):
# # # #         # Perform standard BST delete
# # # #         if root is None:
# # # #             return root

# # # #         if key < root.key:
# # # #             root.left = self.delete(root.left, key, id)
# # # #         elif key > root.key:
# # # #             root.right = self.delete(root.right, key, id)
# # # #         else:
# # # #             if id != root.id:
# # # #                 if id < root.id:
# # # #                     root.left = self.delete(root.left, key, id)
# # # #                 else:
# # # #                     root.right = self.delete(root.right, key, id)
# # # #             else:
# # # #                 # Node with only one child or no child
# # # #                 if root.left is None:
# # # #                     temp = root.right
# # # #                     root = None
# # # #                     return temp
# # # #                 elif root.right is None:
# # # #                     temp = root.left
# # # #                     root = None
# # # #                     return temp

# # # #                 # Node with two children: Get the inorder successor (smallest in the right subtree)
# # # #                 temp = self.min_value_node(root.right)

# # # #                 # Copy the inorder successor's content to this node
# # # #                 root.key = temp.key
# # # #                 root.id = temp.id

# # # #                 # Delete the inorder successor
# # # #                 root.right = self.delete(root.right, temp.key, temp.id)

# # # #         # If the tree had only one node, return
# # # #         if root is None:
# # # #             return root

# # # #         # Update height of the current node
# # # #         root.height = 1 + max(self.height(root.left), self.height(root.right))

# # # #         # Get the balance factor
# # # #         balance = self.get_balance(root)

# # # #         # If the node is unbalanced, there are 4 cases:

# # # #         # Left Left Case
# # # #         if balance > 1 and self.get_balance(root.left) >= 0:
# # # #             return self.right_rotate(root)

# # # #         # Left Right Case
# # # #         if balance > 1 and self.get_balance(root.left) < 0:
# # # #             root.left = self.left_rotate(root.left)
# # # #             return self.right_rotate(root)

# # # #         # Right Right Case
# # # #         if balance < -1 and self.get_balance(root.right) <= 0:
# # # #             return self.left_rotate(root)

# # # #         # Right Left Case
# # # #         if balance < -1 and self.get_balance(root.right) > 0:
# # # #             root.right = self.right_rotate(root.right)
# # # #             return self.left_rotate(root)

# # # #         return root

# # # #     # Wrapper for insert to work with tree root
# # # #     def insert_node(self, key, id):
# # # #         new_node = Node(key, id)
# # # #         self.root = self.insert(self.root, new_node)

# # # #     # Wrapper for delete to work with tree root
# # # #     def delete_node(self, key, id):
# # # #         self.root = self.delete(self.root, key, id)

# # # #     # Utility function for in-order traversal of the tree
# # # #     def in_order_traversal(self, root):
# # # #         if not root:
# # # #             return
# # # #         self.in_order_traversal(root.left)
# # # #         print(f"Key: {root.key}, ID: {root.id}")
# # # #         self.in_order_traversal(root.right)


# # # # # Driver Code
# # # # if __name__ == "__main__":
# # # #     root = None

# # # #     avl = AVLTree()

# # # #     # Function call to insert the nodes
# # # #     avl.insert_node(12, 9)
# # # #     avl.insert_node(22, 5)
# # # #     avl.insert_node(33, 10)
# # # #     avl.insert_node(54, 0)
# # # #     avl.insert_node(1, 6)

# # # #     # Print the tree before deleting node
# # # #     print("Before deletion:")
# # # #     # print_preorder(root)
# # # #     avl.in_order_traversal(root)

# # # #     # Function Call to delete node 10
# # # #     avl.delete_node(root, 10)

# # # #     # Print the tree after deleting node
# # # #     print("After deletion:")
# # # #     # print_preorder(root)
# # # #     avl.in_order_traversal(root) 



# # # def comp_1(node_1, node_2):
# # #     return node_1.key < node_2.key  # Use 'key' instead of 'value'


# # # class AVLTree:
# # #     def __init__(self, compare_function=comp_1):
# # #         self.root = None
# # #         self.size = 0
# # #         self.comparator = compare_function
    
# # #     def height(self, node):
# # #         if not node:
# # #             return 0
# # #         return node.height
    
# # #     def right_rotate(self, y):
# # #         x = y.left
# # #         T2 = x.right

# # #         # Perform rotation
# # #         x.right = y
# # #         y.left = T2

# # #         # Update heights
# # #         y.height = 1 + max(self.height(y.left), self.height(y.right))
# # #         x.height = 1 + max(self.height(x.left), self.height(x.right))

# # #         # Return new root
# # #         return x
    
# # #     def left_rotate(self, x):
# # #         y = x.right
# # #         T2 = y.left

# # #         # Perform rotation
# # #         y.left = x
# # #         x.right = T2

# # #         # Update heights
# # #         x.height = 1 + max(self.height(x.left), self.height(x.right))
# # #         y.height = 1 + max(self.height(y.left), self.height(y.right))

# # #         # Return new root
# # #         return y
    
# # #     def get_balance(self, node):
# # #         if not node:
# # #             return 0
# # #         return self.height(node.left) - self.height(node.right)

# # #     def insert(self, root, new):
# # #         # Perform the normal BST insertion
# # #         if root is None:
# # #             return new
        
# # #         # Use comparator to decide where to insert the new node
# # #         if self.comparator(new, root):
# # #             root.left = self.insert(root.left, new)
# # #         elif self.comparator(root, new):
# # #             root.right = self.insert(root.right, new)
# # #         else:
# # #             # Use the secondary comparison based on `id`
# # #             if new.get_id() < root.get_id():
# # #                 root.left = self.insert(root.left, new)
# # #             else:
# # #                 root.right = self.insert(root.right, new)

# # #         # Update height of this ancestor node
# # #         root.height = 1 + max(self.height(root.left), self.height(root.right))

# # #         # Get the balance factor of this ancestor node
# # #         balance = self.get_balance(root)
    
# # #         # If this node becomes unbalanced, then there are 4 cases

# # #         # Left Left Case
# # #         if balance > 1 and self.comparator(new, root.left):
# # #             return self.right_rotate(root)
    
# # #         # Right Right Case
# # #         if balance < -1 and self.comparator(root.right, new):
# # #             return self.left_rotate(root)
    
# # #         # Left Right Case
# # #         if balance > 1 and self.comparator(root.left, new):
# # #             root.left = self.left_rotate(root.left)
# # #             return self.right_rotate(root)
    
# # #         # Right Left Case
# # #         if balance < -1 and self.comparator(new, root.right):
# # #             root.right = self.right_rotate(root.right)
# # #             return self.left_rotate(root)
    
# # #         return root

# # #     def min_value_node(self, node):
# # #         current = node
# # #         while current.left is not None:
# # #             current = current.left
# # #         return current

# # #     def delete(self, root, key, id):
# # #         # Perform standard BST delete
# # #         if root is None:
# # #             return root

# # #         if key < root.key:
# # #             root.left = self.delete(root.left, key, id)
# # #         elif key > root.key:
# # #             root.right = self.delete(root.right, key, id)
# # #         else:
# # #             if id != root.id:
# # #                 if id < root.id:
# # #                     root.left = self.delete(root.left, key, id)
# # #                 else:
# # #                     root.right = self.delete(root.right, key, id)
# # #             else:
# # #                 # Node with only one child or no child
# # #                 if root.left is None:
# # #                     temp = root.right
# # #                     root = None
# # #                     return temp
# # #                 elif root.right is None:
# # #                     temp = root.left
# # #                     root = None
# # #                     return temp

# # #                 # Node with two children: Get the inorder successor
# # #                 temp = self.min_value_node(root.right)

# # #                 # Copy the inorder successor's content to this node
# # #                 root.key = temp.key
# # #                 root.id = temp.id

# # #                 # Delete the inorder successor
# # #                 root.right = self.delete(root.right, temp.key, temp.id)

# # #         # If the tree had only one node, return
# # #         if root is None:
# # #             return root

# # #         # Update height of the current node
# # #         root.height = 1 + max(self.height(root.left), self.height(root.right))

# # #         # Get the balance factor
# # #         balance = self.get_balance(root)

# # #         # If the node is unbalanced, there are 4 cases:

# # #         # Left Left Case
# # #         if balance > 1 and self.get_balance(root.left) >= 0:
# # #             return self.right_rotate(root)

# # #         # Left Right Case
# # #         if balance > 1 and self.get_balance(root.left) < 0:
# # #             root.left = self.left_rotate(root.left)
# # #             return self.right_rotate(root)

# # #         # Right Right Case
# # #         if balance < -1 and self.get_balance(root.right) <= 0:
# # #             return self.left_rotate(root)

# # #         # Right Left Case
# # #         if balance < -1 and self.get_balance(root.right) > 0:
# # #             root.right = self.right_rotate(root.right)
# # #             return self.left_rotate(root)

# # #         return root

# # #     # Wrapper for insert to work with tree root
# # #     def insert_node(self, key, id):
# # #         new_node = Node(key, id)
# # #         self.root = self.insert(self.root, new_node)

# # #     # Wrapper for delete to work with tree root
# # #     def delete_node(self, key, id):
# # #         self.root = self.delete(self.root, key, id)

# # #     # Utility function for in-order traversal of the tree
# # #     def in_order_traversal(self, root):
# # #         if not root:
# # #             return
# # #         self.in_order_traversal(root.left)
# # #         print(f"Key: {root.key}, ID: {root.id}")
# # #         self.in_order_traversal(root.right)

# # #     # Public method to print in-order traversal
# # #     def print_in_order(self):
# # #         self.in_order_traversal(self.root)

# # # # Example Usage
# # # if __name__ == "__main__":
# # #     avl = AVLTree()
# # #     avl.insert_node(10, 1)
# # #     avl.insert_node(20, 2)
# # #     avl.insert_node(30, 3)
# # #     avl.insert_node(25, 4)

# # #     print("In-order traversal after insertion:")
# # #     avl.print_in_order()

# # #     avl.delete_node(20, 2)
    
# # #     print("\nIn-order traversal after deletion:")
# # #     avl.print_in_order()


# # def comp_1(node_1, node_2):
# #     return node_1.key < node_2.key  # Use 'key' instead of 'value'


# # class AVLTree:
# #     def __init__(self, compare_function=comp_1):
# #         self.root = None
# #         self.size = 0
# #         self.comparator = compare_function
    
# #     def height(self, node):
# #         if not node:
# #             return 0
# #         return node.height
    
# #     def right_rotate(self, y):
# #         x = y.left
# #         T2 = x.right

# #         # Perform rotation
# #         x.right = y
# #         y.left = T2

# #         # Update heights
# #         y.height = 1 + max(self.height(y.left), self.height(y.right))
# #         x.height = 1 + max(self.height(x.left), self.height(x.right))

# #         return x
    
# #     def left_rotate(self, x):
# #         y = x.right
# #         T2 = y.left

# #         # Perform rotation
# #         y.left = x
# #         x.right = T2

# #         # Update heights
# #         x.height = 1 + max(self.height(x.left), self.height(x.right))
# #         y.height = 1 + max(self.height(y.left), self.height(y.right))

# #         return y
    
# #     def get_balance(self, node):
# #         if not node:
# #             return 0
# #         return self.height(node.left) - self.height(node.right)

# #     def insert(self, root, new):
# #         if root is None:
# #             return new
        
# #         if self.comparator(new, root):
# #             root.left = self.insert(root.left, new)
# #         elif self.comparator(root, new):
# #             root.right = self.insert(root.right, new)
# #         else:
# #             if new.id < root.id:
# #                 root.left = self.insert(root.left, new)
# #             else:
# #                 root.right = self.insert(root.right, new)

# #         root.height = 1 + max(self.height(root.left), self.height(root.right))
# #         balance = self.get_balance(root)

# #         # Left Left Case
# #         if balance > 1 and self.comparator(new, root.left):
# #             return self.right_rotate(root)

# #         # Right Right Case
# #         if balance < -1 and self.comparator(root.right, new):
# #             return self.left_rotate(root)

# #         # Left Right Case
# #         if balance > 1 and self.comparator(root.left, new):
# #             root.left = self.left_rotate(root.left)
# #             return self.right_rotate(root)

# #         # Right Left Case
# #         if balance < -1 and self.comparator(new, root.right):
# #             root.right = self.right_rotate(root.right)
# #             return self.left_rotate(root)

# #         return root
    
# #     def min_value_node(self, node):
# #         current = node
# #         while current.left is not None:
# #             current = current.left
# #         return current

# #     def delete(self, root, key, id):
# #         if root is None:
# #             return root

# #         if key < root.key:
# #             root.left = self.delete(root.left, key, id)
# #         elif key > root.key:
# #             root.right = self.delete(root.right, key, id)
# #         else:
# #             if id == root.id:
# #                 # Node with only one child or no child
# #                 if root.left is None:
# #                     temp = root.right
# #                     root = None
# #                     return temp
# #                 elif root.right is None:
# #                     temp = root.left
# #                     root = None
# #                     return temp

# #                 # Node with two children: Get the inorder successor
# #                 temp = self.min_value_node(root.right)

# #                 # Copy the inorder successor's content to this node
# #                 root.key = temp.key
# #                 root.id = temp.id

# #                 # Delete the inorder successor
# #                 root.right = self.delete(root.right, temp.key, temp.id)
# #             else:
# #                 # If the id doesn't match, handle it as per your logic
# #                 if id < root.id:
# #                     root.left = self.delete(root.left, key, id)
# #                 else:
# #                     root.right = self.delete(root.right, key, id)

# #         # If the tree had only one node, return
# #         if root is None:
# #             return root

# #         # Update height of the current node
# #         root.height = 1 + max(self.height(root.left), self.height(root.right))
# #         balance = self.get_balance(root)

# #         # Balance the tree
# #         if balance > 1 and self.get_balance(root.left) >= 0:
# #             return self.right_rotate(root)

# #         if balance > 1 and self.get_balance(root.left) < 0:
# #             root.left = self.left_rotate(root.left)
# #             return self.right_rotate(root)

# #         if balance < -1 and self.get_balance(root.right) <= 0:
# #             return self.left_rotate(root)

# #         if balance < -1 and self.get_balance(root.right) > 0:
# #             root.right = self.right_rotate(root.right)
# #             return self.left_rotate(root)

# #         return root
# #     def insert_node(self, key, id):
# #         new_node = Node(key, id)
# #         self.root = self.insert(self.root, new_node)

# #     def delete_node(self, key, id):
# #         self.root = self.delete(self.root, key, id)

# #     def in_order_traversal(self, root):
# #         if not root:
# #             return
# #         self.in_order_traversal(root.left)
# #         print(f"Key: {root.key}, ID: {root.id}")
# #         self.in_order_traversal(root.right)


# # # Driver Code
# # if __name__ == "__main__":
# #     avl = AVLTree()

# #     avl.insert_node(12, 9)
# #     avl.insert_node(22, 5)
# #     avl.insert_node(33, 10)
# #     avl.insert_node(54, 0)
# #     avl.insert_node(1, 6)

# #     # Print the tree before deleting node
# #     print("Before deletion:")
# #     avl.in_order_traversal(avl.root)

# #     # Function Call to delete node (using correct key and id)
# #     avl.delete_node(33, 10)  # Adjust the key and id you want to delete

# #     # Print the tree after deleting node
# #     print("After deletion:")
# #     avl.in_order_traversal(avl.root)


# def comp_1(node_1, node_2):
#     return node_1.key < node_2.key  # Use 'key' instead of 'value'


# class AVLTree:
#     def __init__(self, compare_function=comp_1):
#         self.root = None
#         self.size = 0
#         self.comparator = compare_function
    
#     def height(self, node):
#         if not node:
#             return 0
#         return node.height
    
#     def right_rotate(self, y):
#         x = y.left
#         T2 = x.right

#         # Perform rotation
#         x.right = y
#         y.left = T2

#         # Update heights
#         y.height = 1 + max(self.height(y.left), self.height(y.right))
#         x.height = 1 + max(self.height(x.left), self.height(x.right))

#         return x
    
#     def left_rotate(self, x):
#         y = x.right
#         T2 = y.left

#         # Perform rotation
#         y.left = x
#         x.right = T2

#         # Update heights
#         x.height = 1 + max(self.height(x.left), self.height(x.right))
#         y.height = 1 + max(self.height(y.left), self.height(y.right))

#         return y
    
#     def get_balance(self, node):
#         if not node:
#             return 0
#         return self.height(node.left) - self.height(node.right)

#     def insert(self, root, new):
#         if root is None:
#             return new
        
#         if self.comparator(new, root):
#             root.left = self.insert(root.left, new)
#         elif self.comparator(root, new):
#             root.right = self.insert(root.right, new)
#         else:
#             if new.id < root.id:
#                 root.left = self.insert(root.left, new)
#             else:
#                 root.right = self.insert(root.right, new)

#         root.height = 1 + max(self.height(root.left), self.height(root.right))
#         balance = self.get_balance(root)

#         # Left Left Case
#         if balance > 1 and self.comparator(new, root.left):
#             return self.right_rotate(root)

#         # Right Right Case
#         if balance < -1 and self.comparator(root.right, new):
#             return self.left_rotate(root)

#         # Left Right Case
#         if balance > 1 and self.comparator(new, root.left):
#             root.left = self.left_rotate(root.left)
#             return self.right_rotate(root)

#         # Right Left Case
#         if balance < -1 and self.comparator(new, root.right):
#             root.right = self.right_rotate(root.right)
#             return self.left_rotate(root)

#         return root
    
#     def min_value_node(self, node):
#         current = node
#         while current.left is not None:
#             current = current.left
#         return current

#     def delete(self, root, key, id):
#         if root is None:
#             return root

#         if key < root.key:
#             root.left = self.delete(root.left, key, id)
#         elif key > root.key:
#             root.right = self.delete(root.right, key, id)
#         else:
#             if id == root.id:
#                 # Node with only one child or no child
#                 if root.left is None:
#                     return root.right
#                 elif root.right is None:
#                     return root.left

#                 # Node with two children: Get the inorder successor
#                 temp = self.min_value_node(root.right)

#                 # Copy the inorder successor's content to this node
#                 root.key = temp.key
#                 root.id = temp.id

#                 # Delete the inorder successor
#                 root.right = self.delete(root.right, temp.key, temp.id)
#             else:
#                 if id < root.id:
#                     root.left = self.delete(root.left, key, id)
#                 else:
#                     root.right = self.delete(root.right, key, id)

#         # If the tree had only one node, return
#         if root is None:
#             return root

#         # Update height of the current node
#         root.height = 1 + max(self.height(root.left), self.height(root.right))
#         balance = self.get_balance(root)

#         # Balance the tree
#         if balance > 1 and self.get_balance(root.left) >= 0:
#             return self.right_rotate(root)

#         if balance > 1 and self.get_balance(root.left) < 0:
#             root.left = self.left_rotate(root.left)
#             return self.right_rotate(root)

#         if balance < -1 and self.get_balance(root.right) <= 0:
#             return self.left_rotate(root)

#         if balance < -1 and self.get_balance(root.right) > 0:
#             root.right = self.right_rotate(root.right)
#             return self.left_rotate(root)

#         return root
    
#     def insert_node(self, key, id):
#         new_node = Node(key, id)
#         self.root = self.insert(self.root, new_node)

#     def delete_node(self, key, id):
#         self.root = self.delete(self.root, key, id)

#     def in_order_traversal(self, root):
#         if not root:
#             return
#         self.in_order_traversal(root.left)
#         print(f"Key: {root.key}, ID: {root.id}")
#         self.in_order_traversal(root.right)


# # Driver Code
# if __name__ == "__main__":
#     avl = AVLTree()

#     avl.insert_node(12, 9)
#     avl.insert_node(22, 5)
#     avl.insert_node(33, 10)
#     avl.insert_node(54, 0)
#     avl.insert_node(1, 6)

#     # Print the tree before deleting node
#     print("Before deletion:")
#     avl.in_order_traversal(avl.root)

#     # Function Call to delete node (using correct key and id)
#     avl.delete_node(33, 10)  # Adjust the key and id you want to delete

#     # Print the tree after deleting node
#     print("After deletion:")
#     avl.in_order_traversal(avl.root)

def comp_1(node_1, node_2):
    
    return node_1.key < node_2.key

class AVLTree:
    def __init__(self, compare_function=comp_1):
        self.root = None
        self.size = 0
        self.comparator = compare_function
    
    def height(self, node):
        if not node:
            return 0
        return node.height
    
    def right_rotate(self, y):
        x = y.left
        T2 = x.right

        x.right = y
        y.left = T2
        if y.parent.left and y.parent.left==y:
            y.parent.left=x
        elif y.parent.right and y.parent.right==y:
            y.parent.right=x


        x.parent=y.parent
        y.parent=x
        T2.parent=y

        y.height = 1 + max(self.height(y.left), self.height(y.right))
        x.height = 1 + max(self.height(x.left), self.height(x.right))

        return x
    
    def left_rotate(self, x):
        y = x.right
        T2 = y.left

        y.left = x
        x.right = T2

        if x.parent.left and x.parent.left==x:
            x.parent.left=y
        elif x.parent.right and x.parent.right==x:
            x.parent.right=y

        y.parent = x.parent 
        x.parent = y
        T2.parent = x
        
        

        x.height = 1 + max(self.height(x.left), self.height(x.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y
    
    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def insert(self, root, new):
        if root is None:
            return new
        
        if self.comparator(new, root):
            root.left = self.insert(root.left, new)
            root.left.parent=root
        elif self.comparator(root, new):
            root.right = self.insert(root.right, new)
            root.right.parent=root
        else:
            if new.id < root.id:
                root.left = self.insert(root.left, new)
                root.left.parent=root
            else:
                root.right = self.insert(root.right, new)
                root.right.parent=root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # Left Left Case
        if balance > 1 and self.comparator(new, root.left):
            return self.right_rotate(root)

        # Right Right Case
        if balance < -1 and self.comparator(root.right, new):
            return self.left_rotate(root)

        # Left Right Case
        if balance > 1 and self.comparator(new, root.left):
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Left Case
        if balance < -1 and self.comparator(new, root.right):
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root
    
    def min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    # def delete(self, root, key, id):
    #     if root is None:
    #         return root

    #     # Traverse the tree to find the node to delete
    #     if key < root.key:
    #         root.left = self.delete(root.left, key, id)
    #     elif key > root.key:
    #         root.right = self.delete(root.right, key, id)
    #     else:  # This means key == root.key
    #         if id == root.id:  # Match the id
    #             # Node with only one child or no child
    #             if root.left is None:
    #                 return root.right
    #             elif root.right is None:
    #                 return root.left

    #             # Node with two children: Get the inorder successor
    #             temp = self.min_value_node(root.right)
    #             root.key = temp.key
    #             root.id = temp.id
    #             root.right = self.delete(root.right, temp.key, temp.id)
    #         else:
    #             # If IDs don't match, continue searching
    #             if id < root.id:
    #                 root.left = self.delete(root.left, key, id)
    #             else:
    #                 root.right = self.delete(root.right, key, id)

    #     # If the node was not found or deleted, return
    #     if root is None:
    #         return root

    #     # Update height and balance the tree
    #     root.height = 1 + max(self.height(root.left), self.height(root.right))
    #     balance = self.get_balance(root)

    #     # Balance the tree
    #     if balance > 1:
    #         if self.get_balance(root.left) < 0:
    #             root.left = self.left_rotate(root.left)
    #         return self.right_rotate(root)

    #     if balance < -1:
    #         if self.get_balance(root.right) > 0:
    #             root.right = self.right_rotate(root.right)
    #         return self.left_rotate(root)

    #     return root


    #     root.height = 1 + max(self.height(root.left), self.height(root.right))
    #     balance = self.get_balance(root)

    #     # Balance the tree
    #     if balance > 1 and self.get_balance(root.left) >= 0:
    #         return self.right_rotate(root)

    #     if balance > 1 and self.get_balance(root.left) < 0:
    #         root.left = self.left_rotate(root.left)
    #         return self.right_rotate(root)

    #     if balance < -1 and self.get_balance(root.right) <= 0:
    #         return self.left_rotate(root)

    #     if balance < -1 and self.get_balance(root.right) > 0:
    #         root.right = self.right_rotate(root.right)
    #         return self.left_rotate(root)

    #     return root

    # def delete_node(self,root, key,id):
    #     # STEP 1: PERFORM STANDARD BST DELETE
    #     if root is None:
    #         return root

    #     # If the key to be deleted is smaller 
    #     # than the root's key, then it lies in 
    #     # left subtree
    #     if key < root.key:
    #         root.left = self.delete_node(root.left, key,id)

    #     # If the key to be deleted is greater 
    #     # than the root's key, then it lies in 
    #     # right subtree
    #     elif key > root.key:
    #         root.right = self.delete_node(root.right, key,id)

    #     # if key is same as root's key, then 
    #     # this is the node to be deleted
    #     else:
    #         # node with only one child or no child
    #         if root.left is None or root.right is None:
    #             temp = root.left if root.left else root.right

    #             # No child case
    #             if temp is None:
    #                 temp2=root.parent
    #                 if temp2.right and temp2.right==root:
    #                     temp2.right=None
    #                 else:
    #                     temp2.left==None
    #             else:  # One child case
    #                 root = temp
    #                 # cur = root
                    
    #                 # if cur.left==temp:
                        
    #                 #     k=1
    #                 # else:
                        
    #                 #     k=0
    #                 # if k==1:



    #         else:
    #             # node with two children: Get the 
    #             # inorder successor (smallest in 
    #             # the right subtree)
    #             temp = self.min_value_node(root.right)

    #             # Copy the inorder successor's 
    #             # data to this node
    #             root.key = temp.key

    #             # Delete the inorder successor
    #             root.right = self.delete_node(root.right, temp.key,id)
    #             # temp=None

    #     # If the tree had only one node then return
    #     if root is None:
    #         return root

    #     # STEP 2: UPDATE HEIGHT OF THE CURRENT NODE
    #     root.height = max(self.height(root.left), 
    #                     self.height(root.right)) + 1

    #     # STEP 3: GET THE BALANCE FACTOR OF THIS 
    #     # NODE (to check whether this node 
    #     # became unbalanced)
    #     balance = self.get_balance(root)

    #     # If this node becomes unbalanced, then 
    #     # there are 4 cases

    #     # Left Left Case
    #     if balance > 1 and self.get_balance(root.left) >= 0:
    #         return self.right_rotate(root)

    #     # Left Right Case
    #     if balance > 1 and self.get_balance(root.left) < 0:
    #         root.left = self.left_rotate(root.left)
    #         return self.right_rotate(root)

    #     # Right Right Case
    #     if balance < -1 and self.get_balance(root.right) <= 0:
    #         return self.left_rotate(root)

    #     # Right Left Case
    #     if balance < -1 and self.get_balance(root.right) > 0:
    #         root.right = self.right_rotate(root.right)
    #         return self.left_rotate(root)

    #     return root

    def delete_node(self, root, key, id):
        print(3)
        if root is None:
            print(4)
            return root
        

        # Traverse the tree to find the node to delete
        if key < root.key:
            print(5)
            root.left = self.delete_node(root.left, key, id)
        elif key > root.key:
            print(6)
            root.right = self.delete_node(root.right, key, id)
        else:
            print(7)
            # Node to be deleted found
            if root.left is None or root.right is None:  # One child or no child
                temp = root.left if root.left else root.right
                print(1)

                if temp is None:  # No child case
                    if root.parent:  # Ensure parent is not None
                        if root.parent.left == root:
                            root.parent.left = None
                            root.parent=None
                        else:
                            root.parent.right = None
                            root.parent=None
                    root = None  # Set root to None
                else:  # One child case
                    temp.parent = root.parent  # Update parent pointer
                    if root.parent:  # Connect parent to child
                        if root.parent.left == root:
                            root.parent.left = temp
                            root.parent=None
                        else:
                            root.parent.right = temp
                            root.parent=None
                    if root.left==temp:
                        root.left = None
                    else:
                        root.right=None
                    # root = temp   Replace root with child
            else:
                print(8)
                # Node with two children
                temp = self.min_value_node(root.right)  # Get inorder successor
                root.key = temp.key  # Replace root's key with successor's key
                root.id = temp.id  # Replace ID if necessary
                root.right = self.delete_node(root.right, temp.key, temp.id)  # Delete successor

        if root is None:
            print(9)
            return root
        print(10)
        # Update the height of the current node
        root.height = 1 + max(self.height(root.left), self.height(root.right))

        # Check the balance of the current node and apply rotations if necessary
        balance = self.get_balance(root)
        print(11)
        # Left Left Case
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        # Left Right Case
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Right Case
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        # Right Left Case
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root


    
    def insert_node(self, key, id):
        new_node = Node(key, id)
        self.root = self.insert(self.root, new_node)

    def delete(self, key, id):
        print(2)
        self.root = self.delete_node(self.root, key, id)

    def in_order_traversal(self, root):
        if not root:
            return
        self.in_order_traversal(root.left)
        if root.parent!=None:
            print(f"Key: {root.key}, ID: {root.id}, Parent: {root.parent.key}, height: {root.height}")

        # print(f"Key: {root.key}, ID: {root.id}")
        self.in_order_traversal(root.right)


# Driver Code
if __name__ == "__main__":
    avl = AVLTree()

    avl.insert_node(12, 9)
    avl.insert_node(22, 5)
    avl.insert_node(33, 10)
    avl.insert_node(54, 0)
    avl.insert_node(1, 6)

    # Print the tree before deleting node
    print("Before deletion:")
    avl.in_order_traversal(avl.root)

    # Function Call to delete node
    avl.delete(5,22)  # Adjust the key and id you want to delete

    # Print the tree after deleting node
    print("After deletion:")
    avl.in_order_traversal(avl.root)

    print("Again Before deletion:")

    avl.insert_node(64,10)
    avl.in_order_traversal(avl.root)

