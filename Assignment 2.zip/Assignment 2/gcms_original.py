from bin import Bin
from avl import AVLTree
from object import Object, Color
from exceptions import NoBinFoundException
from node import Node

class GCMS:
    def __init__(self):
        # Maintain all the Bins and Objects in GCMS
        self.b_id=AVLTree()
        self.b_cap=AVLTree()
        self.o_id=AVLTree()

    # def maxi(self,root):    #Returns max in a tree 

    #     ans= root.

    def Compact_Least(self,obj,node):
        if obj.size>node.size:
            self.Compact_Least(obj,node.right)
        
        elif obj.size<node.size:
            # if node.max_value_node(node.left)>obj.size:
            if self.b_cap.max_value_node(node.left)>obj.size:
                self.Compact_Least(obj,node.left)
            else:
                #found the node to be added
                # cur_nnode=Node(obj.object_id,obj.size)

                # node.av.insert_node(cur_nnode)
                # node.size=node.size-obj.size
                # while(self.b_cap)
                
                #rebalance the tree
                new_size=node.size-obj.size  
                cc_cur_id=node.id
                self.b_cap.delete(node.size,node.id)
                self.b_cap.insert_node_2(new_size,cc_cur_id)
                # #rebalancing process ends


                
                node.ptr.avl.insert_node_2(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
                node.ptr.capacity -= obj.size
                curb_id=node.ptr.bin_id

                nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
                                                                    #(to check if self.b_id.root passses the root or some other node)

                nodee.key=nodee.key-obj.size #updated the size 

                oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

                oid_nodee.ptr=nodee.ptr

                                  
        else:
            cur = node
            while(cur.left and cur.left.size==node.size):
                cur= cur.left
            
            #final cur is obtained where we need to insert the node 

            # (add the code between two red dots)
            node=cur
            #rebalance the tree
            new_size=node.size-obj.size  
            cc_cur_id=node.id
            self.b_cap.delete(node.size,node.id)
            self.b_cap.insert_(new_size,cc_cur_id)
            # #rebalancing process ends


            
            node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
            node.ptr.capacity -= obj.size
            curb_id=node.ptr.bin_id

            nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
                                                                #(to check if self.b_id.root passses the root or some other node)

            nodee.key=nodee.key-obj.size #updated the size 

            oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

            oid_nodee.ptr=nodee.ptr


    def Compact_Max(self,obj,node):
        if obj.size>node.size:
            self.Compact_Least(obj,node.right)
        
        elif obj.size<node.size:
            # if node.max_value_node(node.left)>obj.size:
            if self.b_cap.max_value_node(node.left) and self.b_cap.max_value_node(node.left)>obj.size:
                self.Compact_Least(obj,node.left)
            else:

            # (add the code between two red dots)

                #rebalance the tree
                new_size=node.size-obj.size  
                cc_cur_id=node.id
                self.b_cap.delete(node.size,node.id)
                self.b_cap.insert(new_size,cc_cur_id)
                # #rebalancing process ends


                
                node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
                node.ptr.capacity -= obj.size
                curb_id=node.ptr.bin_id

                nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
                                                                    #(to check if self.b_id.root passses the root or some other node)

                nodee.key=nodee.key-obj.size #updated the size 

                oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

                oid_nodee.ptr=nodee.ptr

        else:

            cur = node 
            while(cur.right and cur.right.size==node.size):
                cur = cur.right 

            # (add the code between two red dots)
            node=cur
            #rebalance the tree
            new_size=node.size-obj.size  
            cc_cur_id=node.id
            self.b_cap.delete(node.size,node.id)
            self.b_cap.insert(new_size,cc_cur_id)
            # #rebalancing process ends


            
            node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
            node.ptr.capacity -= obj.size
            curb_id=node.ptr.bin_id

            nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
                                                                #(to check if self.b_id.root passses the root or some other node)

            nodee.key=nodee.key-obj.size #updated the size 

            oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

            oid_nodee.ptr=nodee.ptr


    # def Largest_Least(self,obj,node):
    #     print("Largest least me aa gya")
    #     # print("object k size(capacity)",obj.size)
    #     # print("Node ka size (cap)",node.key)
    #     # print("Node ka id",node.id)
    #     if node==None:
    #         return None

    #     if obj.size > node.key:
    #         print("obj ka size bda h toh right me chle gye")
    #         self.Largest_Least(obj,node.right)

    #     elif obj.size<node.key:
    #         print("obj ka size chota h toh left me chle gye")
    #         if self.b_cap.max_value_node(node.right):
    #             self.Largest_Least(obj,node.right)
    #         else:
    #             # (add the code between two red dots)

    #             #rebalance the tree
    #             new_size=node.key-obj.size  
    #             cc_cur_id=node.id
    #             self.b_cap.delete(node.key,node.id)
    #             self.b_cap.insert(new_size,cc_cur_id)
    #             # #rebalancing process ends


                
    #             node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
    #             node.ptr.capacity -= obj.size
    #             curb_id=node.ptr.bin_id

    #             nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
    #                                                                 #(to check if self.b_id.root passses the root or some other node)

    #             nodee.key=nodee.key-obj.size #updated the size 

    #             oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

    #             oid_nodee.ptr=nodee.ptr

    #     else:
    #         if self.b_cap.max_value_node(node.right) and self.b_cap.max_value_node(node.right)>node.key:
    #             self.Largest_Least(obj,node.right)
    #         else:

    #             cur = node
    #             while(cur.left and cur.left.size==node.key):
    #                 cur= cur.left

    #             # (add the code between two red dots)
    #             node=cur
    #             #rebalance the tree
    #             new_size=node.key-obj.size  
    #             cc_cur_id=node.id
    #             self.b_cap.delete(node.key,node.id)
    #             self.b_cap.insert(new_size,cc_cur_id)
    #             # #rebalancing process ends


                
    #             node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
    #             node.ptr.capacity -= obj.size
    #             curb_id=node.ptr.bin_id

    #             nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
    #                                                                 #(to check if self.b_id.root passses the root or some other node)

    #             nodee.key=nodee.key-obj.size #updated the size 

    #             oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

    #             oid_nodee.ptr=nodee.ptr
            

































    def Largest_Least(self,obj,node):
        # print(f"for obj=> id: {obj.object_id} , size: {obj.size}")

        # print(f"for node=> id: {node.id} , size: {node.key}")
        pn=None

        cur=node
        while(cur!=None):
            if(cur.key<obj.size):
                cur=cur.right

            elif(cur.key >=obj.size and pn==None):
                pn=cur
                cur=cur.right
            
            elif(cur.key>pn.key):
                pn=cur 
                cur=cur.right 
            
            else:
                cur=cur.right

        cur1=pn

        while(True):
            if(pn.left and pn.left.key==pn.key):
                pn=pn.left
                cur1=cur1.left
            elif (pn.left and pn.left.key!=pn.key):
                cur1=pn.left
                while(cur!=None):
                    if (cur1.key==pn.key):
                        pn=cur1
                        break
                    cur1=cur1.right
            
            if(cur1==None or pn.left==None):
                break
        
        if pn==None:
            raise NoBinFoundException
        
        node=pn
        print("pn",pn.key)
        #rebalance the tree
        new_size=node.key-obj.size  
        cc_cur_id=node.id
        self.b_cap.delete(node.key,node.id)
        self.b_cap.insert_node_2(new_size,cc_cur_id)
        # #rebalancing process ends


        
        node.ptr.avl.insert_node_2(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
        node.ptr.capacity -= obj.size
        curb_id=node.ptr.bin_id

        nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
                                                            #(to check if self.b_id.root passses the root or some other node)

        nodee.key=nodee.key-obj.size #updated the size 

        oid_nodee=self.o_id.search_id(self.o_id.root,obj.size) #found the node of that particular id of object
        print(oid_nodee)
        oid_nodee.ptr=nodee.ptr
        


            

        













































    def Largest_Max(self,obj,node):

        if obj.size > node.size:
            self.Largest_Least(obj,node.right)

        elif obj.size<node.size:
            if self.b_cap.max_value_node(node.right):
                self.Compact_Least(obj,node.right)
            else:
                # (add the code between two red dots)
                #rebalance the tree
                new_size=node.size-obj.size  
                cc_cur_id=node.id
                self.b_cap.delete(node.size,node.id)
                self.b_cap.insert(new_size,cc_cur_id)
                # #rebalancing process ends


                
                node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
                node.ptr.capacity -= obj.size
                curb_id=node.ptr.bin_id

                nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
                                                                    #(to check if self.b_id.root passses the root or some other node)

                nodee.key=nodee.key-obj.size #updated the size 

                oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

                oid_nodee.ptr=nodee.ptr

        else:
            cur = node 
            while(cur.right and cur.right.size==node.size):
                cur = cur.right 
            node=cur
            # (add the code between two red dots)
            #rebalance the tree
            new_size=node.size-obj.size  
            cc_cur_id=node.id
            self.b_cap.delete(node.size,node.id)
            self.b_cap.insert(new_size,cc_cur_id)
            # #rebalancing process ends


            
            node.ptr.avl.insert_node(obj.object_id,obj.size)  #added the object to bin (to add this function done in bin)
            node.ptr.capacity -= obj.size
            curb_id=node.ptr.bin_id

            nodee=self.b_id.search_id(self.b_id.root,curb_id) #searched the node in b_id 
                                                                #(to check if self.b_id.root passses the root or some other node)

            nodee.key=nodee.key-obj.size #updated the size 

            oid_nodee=self.o_id.search_id(self.o_id.root,obj.object_id) #found the node of that particular id of object

            oid_nodee.ptr=nodee.ptr

            

    def add_bin(self, bin_id, capacity):
        cur_bin=Bin(bin_id,capacity)
        print("in the formed bin id:",cur_bin.bin_id," cap: ",cur_bin.capacity)
        self.b_id.insert_node_3(bin_id,capacity,cur_bin)
        print('insert or not',self.b_id.root.key,self.b_id.root.id)
        # # print(type(self.b_id.root.ptr))
        # print('ptr ',self.b_id.root.ptr.bin_id,self.b_id.root.ptr.capacity)
        self.b_cap.insert_node_3_cap(capacity,bin_id,cur_bin)
        # print('insert or not',self.b_cap.root.key,self.b_cap.root.id)
        # # print(type(self.b_id.root.ptr))
        # print('ptr ',self.b_cap.root.ptr.bin_id,self.b_cap.root.ptr.capacity)
        # print('$b-id',self.b_id.root.key,self.b_id.root.id)
        # print('$b-cap',self.b_cap.root.key,self.b_cap.root.id)
        cur_id=self.b_id.search_id(self.b_id.root,bin_id)
        # 1234 10
        # 1234
        # print(cur_id.key,cur_cap.key)
        cur_cap=self.b_cap.search_key(self.b_cap.root,capacity)
        # print(cur_id.key,cur_cap.key)
        # raise NoBinFoundException
        # if cur_id and cur_bin:
        # print(f"ID wise => Key: {cur_id.get_key()} and id: {cur_id.get_id()} ")
        # print(f"CAP wise => Key: {cur_cap.get_key()} and id: {cur_cap.get_id()} ")


        pass

    # def add_object(self, object_id, size, color):
    #     ## adding bin id and cap. in the trees 
    #     cur_obj=Object(object_id, size, color)
    #     # self.o_id.insert_node_3(object_id,size,cur_obj)
    #     self.o_id.insert_node_3(size,object_id,cur_obj)
    #     print("color wali id and key",self.o_id.root.id,self.o_id.root.key)
    #     print("obj wali color wali id and key",cur_obj.object_id,cur_obj.size)


    #     if (color==Color.BLUE):
    #         self.Compact_Least(cur_obj,self.b_cap.root)
        
    #     elif (color==Color.YELLOW):
    #         self.Compact_Max(cur_obj,self.b_cap.root)

    #     elif (color==Color.RED):
    #         print(1)
    #         self.Largest_Least(cur_obj,self.b_cap.root)

    #     elif (color==Color.GREEN):
    #         self.Largest_Max(cur_obj,self.b_cap.root)

    # def delete_object(self, object_id):
    #     # Implement logic to remove an object from its bin

    #     my_obj = self.o_id.search_id(self.o_id.root,object_id) #node obtained which has the id of the particular object
    #     obj_size= my_obj.key
    #     b=my_obj.ptr #came to bin
    #     b_i= b.bin_id

    #     b.avl.delete(object_id,obj_size) #to check if this 0 works as the cap

    #     my_obj.ptr=None
    #     self.o_id.delete(object_id,obj_size) #deleting the object from o_id avl tree

    #     cur_bin_id=self.b_id.search_id(self.b_id.root,b_i) #node in b_id obtained of the bin cap in which deletion was made  
    #     b_c=cur_bin_id.key
    #     cur_bin_id.key+=obj_size
        
    #     cur_bin_cap=self.b_cap.search_key(self.b_cap.root,b_c)
    #     b_cap=cur_bin_cap.key
    #     b_iid=cur_bin_cap.id
    #     self.b_cap.delete(cur_bin_cap.id,cur_bin_cap.key)
    #     self.b_cap.insert_node_2(b_cap,b_iid)

    #     # cur_bin_cap.key+=obj_size

    #     ##REBALANCE THE NODE


    #     pass

    # def bin_info(self, bin_id):
    #     # returns a tuple with current capacity of the bin and the list of objects in the bin (int, list[int])
    #     print("search in bin info for bin id ", bin_id)
    #     cur_bin_id = self.b_id.search_id(self.b_id.root,bin_id)
    #     # print(cur_bin_id)
    #     cur_bin=cur_bin_id.ptr
    #     ans=[]
    #     cur_bin.avl.in_order_traversal(cur_bin.avl.root,ans)
    #     tup = (cur_bin.capacity,ans)

    #     return tup

    #     pass

    # def object_info(self, object_id):
    #     # returns the bin_id in which the object is stored
    #     cur_o_id=self.o_id.search_id(self.o_id.root,object_id)
    #     cur_b=cur_o_id.ptr
    #     return cur_b.bin_id
    
    #     pass
    
