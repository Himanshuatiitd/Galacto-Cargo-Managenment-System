gcms.add_object(8989, 6, Color.GREEN )
    