from node import Node

def comp_1(node_1, node_2):
    
    return node_1.key < node_2.key

class AVLTree:
    def __init__(self, compare_function=comp_1):
        self.root = None
        self.size = 0
        self.comparator = compare_function
    
    def height(self, node):
        if not node:
            return 0
        return node.height
    
    def right_rotate(self, y):
        x = y.left
        T2 = x.right

        x.right = y
        y.left = T2
        if y and y.parent and y.parent.left and y.parent.left==y:
            y.parent.left=x
        elif y and y.parent and y.parent.right and y.parent.right==y:
            y.parent.right=x

        if x and y : 
            x.parent=y.parent
        if y :    
            y.parent=x
        if T2 :
            T2.parent=y

        y.height = 1 + max(self.height(y.left), self.height(y.right))
        x.height = 1 + max(self.height(x.left), self.height(x.right))

        return x
    
    def left_rotate(self, x):
        y = x.right
        T2 = y.left

        y.left = x
        x.right = T2

        if  x and x.parent and x.parent.left and x.parent.left==x:
            x.parent.left=y
        elif x and x.parent and  x.parent.right and x.parent.right==x:
            x.parent.right=y

        if x and y : 
            y.parent = x.parent 
        if x :
            x.parent = y
        if T2 :
            T2.parent = x

        

        x.height = 1 + max(self.height(x.left), self.height(x.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y
    
    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def insert(self, root, new):
        if root is None:
            # new.ptr=my_bin

            return new
        
        if root.key >new.key:
            root.left = self.insert(root.left, new)
            root.left.parent=root
        elif root.key <new.key:
            root.right = self.insert(root.right, new)
            root.right.parent=root
        else:
            if new.id < root.id:
                root.left = self.insert(root.left, new)
                root.left.parent=root
            else:
                root.right = self.insert(root.right, new)
                root.right.parent=root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # Left Left Case
        if balance > 1 and self.comparator(new, root.left):
            return self.right_rotate(root)

        # Right Right Case
        if balance < -1 and self.comparator(root.right, new):
            return self.left_rotate(root)

        # Left Right Case
        if balance > 1 and self.comparator(new, root.left):
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Left Case
        if balance < -1 and self.comparator(new, root.right):
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def insert_cap(self, root, new):
        # print("root", root.id,root.key)
        print("node",new.id,new.key)
        if root is None:
            # new.ptr=my_bin

            return new
    
        
        if root.key >new.key:
            root.left = self.insert(root.left, new)
            root.left.parent=root
        elif root.key <new.key:
            root.right = self.insert(root.right, new)
            root.right.parent=root
        else:
            if new.id < root.id:
                root.left = self.insert(root.left, new)
                root.left.parent=root
            else:
                root.right = self.insert(root.right, new)
                root.right.parent=root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # Left Left Case
        if balance > 1 and self.comparator(new, root.left):
            return self.right_rotate(root)

        # Right Right Case
        if balance < -1 and self.comparator(root.right, new):
            return self.left_rotate(root)

        # Left Right Case
        if balance > 1 and self.comparator(new, root.left):
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Left Case
        if balance < -1 and self.comparator(new, root.right):
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root
    
    def min_value_node(self, node):
        if node==None:
            return 0
        current = node
        while current.left is not None:
            current = current.left
        return current
    
    def max_value_node(self, node):
        if node==None:
            return 0
        current = node
        while current.right is not None:
            current = current.right
        return current.key

    def delete_node(self, root, key, id):
        print(3)
        if root is None:
            print(4)
            return root
        

        # Traverse the tree to find the node to delete
        if key < root.key:
            print(5)
            root.left = self.delete_node(root.left, key, id)
        elif key > root.key:
            print(6)
            root.right = self.delete_node(root.right, key, id)
        else:
            if(id>root.id):
                root.right = self.delete_node(root.right, key, id)
            
            elif(id<root.id):
                root.left = self.delete_node(root.left, key, id)
                print(7)
                # Node to be deleted found
            else:   
            
                if root.left is None or root.right is None:  # One child or no child
                    temp = root.left if root.left else root.right
                    print(1)

                    if temp is None:  # No child case
                        if root.parent:  # Ensure parent is not None
                            if root.parent.left == root:
                                root.parent.left = None
                                root.parent=None
                            else:
                                root.parent.right = None
                                root.parent=None
                        root = None  # Set root to None
                    else:  # One child case
                        temp.parent = root.parent  # Update parent pointer
                        if root.parent:  # Connect parent to child
                            if root.parent.left == root:
                                root.parent.left = temp
                                root.parent=None
                            else:
                                root.parent.right = temp
                                root.parent=None
                        if root.left==temp:
                            root.left = None
                        else:
                            root.right=None
                        # root = temp   Replace root with child
                else:
                    print(8)
                    # Node with two children
                    temp = self.min_value_node(root.right)  # Get inorder successor
                    root.key = temp.key  # Replace root's key with successor's key
                    root.id = temp.id  # Replace ID if necessary
                    root.right = self.delete_node(root.right, temp.key, temp.id)  # Delete successor

        if root is None:
            print(9)
            return root
        print(10)
        # Update the height of the current node
        root.height = 1 + max(self.height(root.left), self.height(root.right))

        # Check the balance of the current node and apply rotations if necessary
        balance = self.get_balance(root)
        print(11)
        # Left Left Case
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        # Left Right Case
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Right Case
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        # Right Left Case
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root
    

    # def search_key(self,node,num):
    #     if node is None:
    #         return None
    #     elif num==node.key:
    #         return node
        
    #     elif num>node.key:
    #         return self.search_key(node.right,num)
        
    #     else:
    #         return self.search_key(node.left,num)
        

    # def search_id(self,node,num):
    #     if node is None:
    #         return None
    #     elif num==node.id:
    #         return node
        
    #     elif num>node.id:
    #         return self.search_id(node.right,num)
        
    #     else:
    #         return self.search_id(node.left,num)
        
    def search_id(self,root:Node,key):
        
        if root==None:
            print('empty')
            return None
        # print(root.key,'->key')
        # print(key,'-> input')
        # print(root.id,'->id')
        print("search arg",)
        if root.key==key:
            print('found')
            return root
        elif root.key>key:
            # print("found 1")
            return self.search_id(root.left,key)
        elif root.key<key:
            # print("found 2")
            return self.search_id(root.right,key)
        

    # def search_key(self,key,root:Node,key1):
    #     if root.key1==key and root.key2==key1:
    #         return root
    #     elif root.key1<key or (root.key1==key and root.key2<key1):
    #         return self.search_node_id(key,root.right,key1)
    #     elif root.key1>key or (root.key1==key and root.key2>key1):
    #         return self.search_node_capacity(key,root.left,key1)
    def search_key(self,root:Node,key):
        # print(root.key,'->key')
        # print(key,'-> input')
        # print(root.id,'->id')
        if root==None:
            # print('empty')
            return None
        if root.key==key:
            # print('found')
            return root
        elif root.key>key:
            return self.search_key(root.left,key)
        elif root.key<key:
            return self.search_key(root.right,key)

    def insert_node_3(self, val_1, val_2,my_b):
        new_node = Node(val_2, val_1)
        print("insert 3 val_1:",val_1,"val_2",val_2)
        print("node formed val_1(key):",new_node.key,"val_2(id)",new_node.id)

        new_node.ptr=my_b        
        self.root = self.insert(self.root, new_node)


    def insert_node_3_cap(self, val_1, val_2,my_b):
        new_node = Node(val_1, val_2)
        print("insert 3 cap val_1:",val_1,"val_2",val_2)
        print("node formed cap val_1(key):",new_node.key,"val_2(id)",new_node.id)

        new_node.ptr=my_b        
        self.root = self.insert_cap(self.root, new_node)

    def insert_node_2(self, key, id):
        new_node = Node(key, id)       
        self.root = self.insert(self.root, new_node)

    def insert_node_1(self, nnode):
            
        self.root = self.insert(self.root,nnode)

    # def insert_node(self, *args):
    #     if len(args) == 1:  # Case: Only node object passed
    #         nnode = args[0]
    #         self.root = self.insert(self.root, nnode)
            
    #     elif len(args) == 2:  # Case: key and id passed
    #         key = args[0]
    #         id = args[1]
    #         new_node = Node(key, id)
    #         self.root = self.insert(self.root, new_node)

    #     elif len(args) == 3:  # Case: bin_id, capacity, and Bin passed
    #         bin_id = args[0]
    #         capacity = args[1]
    #         Bin = args[2]
    #         new_node = Node(bin_id, capacity)
    #         new_node.ptr = Bin
    #         self.root = self.insert(self.root, new_node)


    def balance(self, node):
        # Get the balance factor
        balance = self.get_balance(node)
        
        # If the node becomes unbalanced, then there are 4 cases

        # Left Left Case
        if balance > 1 and self.get_balance(node.left) >= 0:
            return self.right_rotate(node)

        # Left Right Case
        if balance > 1 and self.get_balance(node.left) < 0:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        # Right Right Case
        if balance < -1 and self.get_balance(node.right) <= 0:
            return self.left_rotate(node)

        # Right Left Case
        if balance < -1 and self.get_balance(node.right) > 0:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        # Return the balanced node
        return node


    # def insert_node(self, new_node):
    #     self.root = self.insert(self.root, new_node)

    def delete(self, key, id):
        print(2)
        self.root = self.delete_node(self.root, key, id)

    # def in_order_traversal(self, root):
    #     if not root:
    #         return
    #     self.in_order_traversal(root.left)
    #     if root.parent!=None:
    #         print(f"Key: {root.key}, ID: {root.id}, Parent: {root.parent.key}, height: {root.height}")

    #     # print(f"Key: {root.key}, ID: {root.id}")
    #     self.in_order_traversal(root.right)

    def in_order_traversal(self, root,li):
        if not root:
            return
        self.in_order_traversal(root.left,li)
        # if root.parent!=None:
        #     print(f"Key: {root.key}, ID: {root.id}, Parent: {root.parent.key}, height: {root.height}")

        li.append(root.id)
        # print(f"Key: {root.key}, ID: {root.id}")
        self.in_order_traversal(root.right,li)
        return

    # def in_order_traversal(self, root):
    #     if not root:
    #         return
    #     self.in_order_traversal(root.left)
    #     if root.parent!=None:
    #         print(f"Key: {root.key}, ID: {root.id}, Parent: {root.parent.key}, height: {root.height}")

    
    #     # print(f"Key: {root.key}, ID: {root.id}")
    #     self.in_order_traversal(root.right)
        

# # Driver Code
# if __name__ == "__main__":
#     avl = AVLTree()

#     # avl.insert_node(12, 25)
#     # avl.insert_node(22, 50)
#     # avl.insert_node(33, 10)
#     # avl.insert_node(54, 30)
#     # avl.insert_node(1, 20)
#     avl.insert_node_2(6,12)
#     avl.insert_node_2(9,22)
#     avl.insert_node_2(10,33)
#     avl.insert_node_2(3,54)
#     avl.insert_node_2(2,1)
#     avl.insert_node_2(1,12)
#     avl.insert_node_2(8,23)
#     avl.insert_node_2(7,33)
#     # avl.insert_node(54, 30)
#     # avl.insert_node(1, 20)

#     # Print the tree before deleting node
#     print("Before deletion:")
#     avl.in_order_traversal(avl.root)

#     # Function Call to delete node
#     avl.delete(1,12)  # Adjust the key and id you want to delete

#     # Print the tree after deleting node
#     # print("After deletion:")
#     # avl.in_order_traversal(avl.root)

#     print("Again Before deletion:")

#     # avl.insert_node(64,19)
#     avl.in_order_traversal(avl.root)
#     print(avl.search_key(avl.root,8).key)

